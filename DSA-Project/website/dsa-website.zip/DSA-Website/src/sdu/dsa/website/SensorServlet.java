package sdu.dsa.website;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SensorServlet.
 */
@WebServlet(description = "Sensor Details", urlPatterns = { "/SensorServlet" })
public class SensorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * Default Constructor.
     * @see HttpServlet#HttpServlet() */
    public SensorServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	
	/**
	 * Method processRequest.
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @throws ServletException
	 * @throws IOException
	 */
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			int id = Integer.parseInt(request.getParameter("id"));
			String action = request.getParameter("action");
			
			if (action != null && action.equalsIgnoreCase("changeSleeptime")) {
				String sleeptimeString = request.getParameter("sleeptime");
				if (sleeptimeString != null) {
					try {
						int sleeptime = Integer.parseInt(sleeptimeString);
						request.setAttribute("message", "sleeptime changed");
						DBManager.setSensorSleeptime(id, sleeptime);
					} catch (NumberFormatException nfe) {
						// sleeptime not valid
						request.setAttribute("message", "Sleeptime not valid");
					}
				}
			}
			
			int limit = 10;
			String limitString = request.getParameter("limit");
			if (limitString != null) {
				try {
					limit = Integer.parseInt(limitString);
				} catch (Exception e) {
					request.setAttribute("message", "Limit not valid. Automatically set to 10");
				}
			}

			request.setAttribute("limit", limit);
			
			ArrayList<RecordLine> table = DBManager.getSensorRecords(id, limit);
			request.setAttribute("table", table);
			
			getServletConfig().getServletContext().getRequestDispatcher("/sensordetails.jsp").include(request, response);
			
		} catch (NumberFormatException nfe) {
			// Id not valid
			request.setAttribute("errorMessage", "Id not valid");
			getServletConfig().getServletContext().getRequestDispatcher("/error.jsp").include(request, response);
		}
		
		
	}
}
