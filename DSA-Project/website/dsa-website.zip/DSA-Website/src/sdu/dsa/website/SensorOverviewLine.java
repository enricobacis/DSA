package sdu.dsa.website;

/**
 * A class to wrap all the informations about a sensor that have to be shown in the
 * Home Servlet.
 *
 * @author DSA-Project Group [Spring 2012]
 * @version 1.0
 */
public class SensorOverviewLine extends RecordLine {

	private int sensorID = 0;
	private String description = "";
	private int sleeptime = 0;
	
	/**
	 * Empty Constructor.
	 */
	public SensorOverviewLine() {
		super();
	}
	
	/**
	 * Constructor for SensorOverviewLine.
	 * @param sensorID the sensor ID
	 * @param description the description of the sensor
	 * @param sleeptime the sleeptime
	 */
	public SensorOverviewLine(int sensorID, String description, int sleeptime) {
		this.sensorID = sensorID;
		this.description = description;
		this.sleeptime = sleeptime;
	}

	/**
	 * Constructor for SensorOverviewLine.
	 * @param sensorID the sensor ID
	 * @param description the description of the sensor
	 * @param temperature the temperature
	 * @param humidity the humidity
	 * @param timestamp the timestamp
	 * @param sleeptime the sleeptime
	 */
	public SensorOverviewLine(int sensorID, String description, float temperature, float humidity, long timestamp, int sleeptime) {
		super(temperature, humidity, timestamp);
		this.sensorID = sensorID;
		this.description = description;
		this.sleeptime = sleeptime;
	}
	
	/**
	 * Method getSensorID.
	 * @return the sensor ID
	 */
	public int getSensorID() {
		return sensorID;
	}
	
	/**
	 * Method setSensorID.
	 * @param sensorID the sensor ID
	 */
	public void setSensorID(int sensorID) {
		this.sensorID = sensorID;
	}
	
	/**
	 * Method getDescription.
	 * @return the description of the sensor
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * Method setDescription.
	 * @param description the description of the sensor
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * Method getSleeptime.
	 * @return the sleeptime
	 */
	public int getSleeptime() {
		return sleeptime;
	}
	
	/**
	 * Method setSleeptime.
	 * @param sleeptime the sleeptime
	 */
	public void setSleeptime(int sleeptime) {
		this.sleeptime = sleeptime;
	}
	
	/**
	 * Method toString.
	 * @return a string representation of the object.
	 */
	@Override
	public String toString() {
		return "SensorOverviewLine [sensorID=" + sensorID + ", description="
				+ description + ", temperature=" + super.getTemperature() + ", humidity="
				+ super.getHumidity() + ", timestamp=" + super.getTimestamp() + ", sleeptime="
				+ sleeptime + "]";
	}
}
