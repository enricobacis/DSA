package sdu.dsa.website;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/** Database Manager.
*
* @author DSA-Project Group [Spring 2012]
* @version 1.0
*/
public class DBManager {
	
	// Change your connection data here
	private static final String connectionString = "jdbc:mysql://localhost:3306/DSA";
	private static final String username = "root";
	private static final String password = "root";

	/**
	 * JDBC Connection
	 */
	private static Connection connection;

	private static final String sqlSensor = "SELECT id, description, sleeptime " +
			"FROM sensor";

	private static final String sqlRecord = "SELECT temperature, humidity, timestamp " +
			"FROM record " +
			"WHERE sensorID = ? " +
			"ORDER BY timestamp DESC " +
			"LIMIT 1";

	/**
	 * Private Constructor.
	 */
	private DBManager() {}

	/**
	 * Method getConnection.
	 * @return the existing open connection to the database or a new one if no open connections are present. 
	 */
	public static Connection getConnection() {
		if (connection == null) {
			try	{
				Class.forName("com.mysql.jdbc.Driver");

				//Get a connection
				connection = DriverManager.getConnection(connectionString, username, password);
			} catch (Exception except) {
				except.printStackTrace();
			}
		}
		return connection;
	}

	/**
	 * Method closeConnection.
	 */
	public static void closeConnection() {
		try {
			if (connection != null && !connection.isClosed()) {
				connection.close();
				connection = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method getOverview.
	 * @return an ArrayList of SensorOverviewLine to be used in the Home Servlet.
	 */
	public static ArrayList<SensorOverviewLine> getOverview() {

		ArrayList<SensorOverviewLine> overview = new ArrayList<SensorOverviewLine>();

		try {
			ResultSet sensors = getConnection().createStatement().executeQuery(sqlSensor);
			PreparedStatement recordStatement = getConnection().prepareStatement(sqlRecord);
			ResultSet record;
			SensorOverviewLine sensorLine;

			while (sensors.next()) {
				int id = sensors.getInt("id");
				recordStatement.setInt(1, id);
				record = recordStatement.executeQuery();

				sensorLine = new SensorOverviewLine(id,
						sensors.getString("description"),
						sensors.getInt("sleeptime"));

				if (record.next()) {
					sensorLine.setTemperature(record.getFloat("temperature"));
					sensorLine.setHumidity(record.getFloat("humidity"));
					sensorLine.setTimestamp(record.getLong("timestamp"));
				}

				overview.add(sensorLine);			
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return overview;
	}

	/**
	 * Method getSensorRecords.
	 * @param sensorID the ID of the sensor you want the data.
	 * @param limit the number of newest records you want to have. 
	 * @return an ArrayList of RecordLine to be used in the Sensor Servlet.
	 */
	public static ArrayList<RecordLine> getSensorRecords(int sensorID, int limit) {
		ArrayList<RecordLine> table = new ArrayList<RecordLine>();

		String sql = "SELECT temperature, humidity, timestamp " +
				"FROM record " +
				"WHERE sensorID = " + sensorID + " " +
				"ORDER BY timestamp DESC " +
				"LIMIT " + limit;

		try {
			ResultSet records = getConnection().createStatement().executeQuery(sql);

			while (records.next()) {
				table.add(new RecordLine(records.getFloat("temperature"),
						records.getFloat("humidity"),
						records.getLong("timestamp")));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return table;
	}
	
	/**
	 * Set the sleeptime of a sensor.
	 * @param sensorID the sensor ID.
	 * @param sleeptime the sleeptime in ms.
	 */
	public static void setSensorSleeptime(int sensorID, int sleeptime) {
		String sqlUpdateSleeptime = "UPDATE sensor " +
				"SET changed=1, " +
				"sleeptime=" + sleeptime + " " +
				"WHERE id=" + sensorID;
		
		try {
			getConnection().createStatement().executeUpdate(sqlUpdateSleeptime);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
