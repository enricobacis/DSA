package sdu.dsa.website;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Class to wrap all the information of a record in the database.
 *
 * @author DSA-Project Group [Spring 2012]
 * @version 1.0
 */
public class RecordLine {

	private String temperature = "/";
	private String humidity = "/";
	private long timestamp = 0;
	
	/**
	 * Empty constructor.
	 */
	public RecordLine() { }

	/**
	 * Constructor for RecordLine.
	 * @param temperature the temperature
	 * @param humidity the humidity
	 * @param timestamp the timestamp
	 */
	public RecordLine(float temperature, float humidity, long timestamp) {

		this.temperature = Float.toString(temperature);
		this.humidity = Float.toString(humidity);
		this.timestamp = timestamp;
	}
	
	/**
	 * Method getTemperature.
	 * @return the temperature
	 */
	public String getTemperature() {
		return temperature;
	}
	
	/**
	 * Method setTemperature.
	 * @param temperature the temperature
	 */
	public void setTemperature(float temperature) {
		this.temperature = Float.toString(temperature);
	}
	
	/**
	 * Method getHumidity.
	 * @return the humidity
	 */
	public String getHumidity() {
		return humidity;
	}
	
	/**
	 * Method setHumidity.
	 * @param humidity the humidity
	 */
	public void setHumidity(float humidity) {
		this.humidity = Float.toString(humidity);
	}
	
	/**
	 * Method getTimestamp.
	 * @return the timestamp
	 */
	public String getTimestamp() {
		if (timestamp == 0)
			return "/";
		
		SimpleDateFormat formatter = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss");
		return formatter.format(new Date(timestamp));
	}
	
	/**
	 * Method setTimestamp.
	 * @param timestamp the timestamp
	 */
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * Method toString.
	 * @return a string representation of the object.
	 */
	@Override
	public String toString() {
		return "RecordLine [temperature=" + temperature + ", humidity="
				+ humidity + ", timestamp=" + timestamp + "]";
	}
	
}
