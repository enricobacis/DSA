package sdu.dsa.website;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Home.
 *
 * @author DSA-Project Group [Spring 2012]
 * @version 1.0
 */
@WebServlet(description = "Sensors Overview", urlPatterns = { "/Home" })
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public HomeServlet() {
    	super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	
	/**
	 * Method processRequest.
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @throws ServletException
	 * @throws IOException
	 */
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<SensorOverviewLine> overview = DBManager.getOverview();
		
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<head>");
		out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
		out.println("<title>Sensors Overview</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<div align=\"center\">");
		out.println("<h1>Sensors Overview</h1>");
		out.println("<br />");
		out.println("<table border=\"1\">");
		
		out.println("<tr>");
		out.print("<th>ID</th>");
		out.print("<th>Description</th>");
		out.print("<th>Temperature</th>");
		out.print("<th>Humidity</th>");
		out.print("<th>Date</th>");
		out.println("<th>Sleeptime</th>");
		out.println("</tr>");
		
		for (SensorOverviewLine line : overview) {
			int id = line.getSensorID();
			
			out.println("<tr>");
			out.println("<td><a href=\"SensorServlet?id=" + id + "\">" + id + "</a></td>");
			out.println("<td>" + line.getDescription() + "</td>");
			out.println("<td>" + line.getTemperature() + "</td>");
			out.println("<td>" + line.getHumidity() + "</td>");
			out.println("<td>" + line.getTimestamp() + "</td>");
			out.println("<td>" + line.getSleeptime() + "</td>");
			out.println("</tr>");
		}

		out.println("</table>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
	}

}
